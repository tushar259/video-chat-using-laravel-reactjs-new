<script src="https://js.pusher.com/7.0/pusher.min.js"></script>
<?php $__env->startSection('content'); ?>
<div id="app">
    
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\chatapp\resources\views/home.blade.php ENDPATH**/ ?>