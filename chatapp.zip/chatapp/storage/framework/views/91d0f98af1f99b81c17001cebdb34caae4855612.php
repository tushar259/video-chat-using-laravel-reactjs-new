<?php $__env->startSection('content'); ?>
<div id="app">
    
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Downloads\LARAVEL VIDEO CHAT PROJECT REACTJS\chatapp\resources\views/home.blade.php ENDPATH**/ ?>