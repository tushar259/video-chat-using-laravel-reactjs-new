@extends('layouts.app')
<script src="https://js.pusher.com/7.0/pusher.min.js"></script>
@section('content')
<div id="app">
    
</div>
@endsection
