import React, {Component} from 'react';
import ReactDOM from 'react-dom';
import MediaHandler from '../MediaHandler';
import Pusher from 'pusher-js';
import Peer from 'simple-peer';

const APP_KEY = 'a384f250f86af1f16f98';

export default class App extends Component{
    // CODE FROM YOUTUBE VIDEO
    /*constructor(){
        super();

        this.state = {
            hasMedia: false,
            otherUserId: null
        };

        this.mediaHandler = new MediaHandler();
    }*/
    // CODE FROM YOUTUBE VIDEO

    constructor(props) {
        super(props);

        this.user = window.user;
        this.user.stream = null;
        this.peers = {};

        this.videoTag = React.createRef();
        this.userVideoTag = React.createRef();

        this.setupPusher();

        this.callTo = this.callTo.bind(this);
        this.setupPusher = this.setupPusher.bind(this);
        this.startPeer = this.startPeer.bind(this);

    }

    componentWillMount(){
        // CODE FROM YOUTUBE VIDEO
        /*this.mediaHandler.getPermissions()    
            .then((stream) => {
                this.setState({hasMedia: true});

                try{
                    this.myVideo.srcObject = stream;
                } catch(e){
                    this.myVideo.src = URL.createObjectURL(stream);
                    
                }

                this.myVideo.play();
            })*/
            // CODE FROM YOUTUBE VIDEO
        navigator.mediaDevices
        .getUserMedia({video: true, audio: true})
        .then((stream) => {
            this.videoTag.current.srcObject = stream;
            this.user.stream = stream;
        })
        .catch(console.log);
    }

    setupPusher(){
        Pusher.logToConsole = true;
        this.pusher = new Pusher(APP_KEY,{
            authEndpoint: 'http://localhost/chatapp/pusher/auth',
            cluster: 'ap2',
            auth:{
                params: this.user.id,
                headers:{
                    'X-CSRF-Token': window.csrfToken
                }
            }
        });

        this.channel = this.pusher.subscribe('presence-video-channel');

        this.channel.bind(`client-signal-${this.user.id}`,(signal) => {
            let peer = this.peers[signal.userId];

            // if peer is not already exists, we got an incoming call
            if(peer == undefined){
                this.setState({otherUserId: signal.userId});
                peer = this.startPeer(signal.userId, false);
            } 
            peer.signal(signal.data);
        });
    }

    startPeer(userId, initiator = true){
        const peer = new Peer({
            initiator,
            stream: this.user.stream,
            trickle: false
        });

        peer.on('signal', (data) => {
            this.channel.trigger(`client-signal-${userId}`, {
                type: 'signal',
                userId: this.user.id,
                data: data
            });
        });

        peer.on('stream', (stream) => {
            try{
                this.userVideoTag.current.srcObject = stream;
            } catch(e){
                console.log(e);
            }
        });

        peer.on('close', () => {
            let peer = this.peers[userId];
            if(peer == undefined){
                peer.destroy();
            }

            this.peers[userId] = undefined;
        });

        return peer;
    }

    callTo(userId){
        this.peers[userId] = this.startPeer(userId);
    }
    
    render(){
        return (
            <div className="App">
                {[1,2,3,4].map((userId) => {
                    return this.user.id != userId ? <button key={userId} onClick={() => this.callTo(userId)}>Call {userId}</button> : null;
                })}
                <div className="video-container">
                   
                    <video 
                        className="my-video"
                        ref={this.videoTag}
                        controls volume="true"
                        autoPlay
                    ></video>

                    <video 
                        className="user-video"
                        ref={this.userVideoTag}
                        controls volume="true"
                        autoPlay
                    ></video>
                    
                    
                </div>

            </div>
        );
    }
}

if (document.getElementById('app')) {
    ReactDOM.render(<App />, document.getElementById('app'));
}
